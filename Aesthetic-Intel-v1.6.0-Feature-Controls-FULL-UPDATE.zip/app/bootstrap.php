<?php
declare(strict_types=1);
define('ROOT_PATH', dirname(__DIR__));
define('APP_PATH', ROOT_PATH.'/app');
define('VIEW_PATH', ROOT_PATH.'/views');
define('STORAGE_PATH', ROOT_PATH.'/storage');
$restoreLock = STORAGE_PATH.'/restore.lock';
if (is_file($restoreLock)) {
    $age = time() - (int)(filemtime($restoreLock) ?: time());
    if ($age > 3600) {
        @unlink($restoreLock);
    } else {
        http_response_code(503);
        header('Retry-After: 120');
        header('Content-Type: text/html; charset=utf-8');
        exit('<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Aesthetic Intel maintenance</title></head><body style="font-family:system-ui;background:#f4f7fb;color:#10213d;display:grid;place-items:center;min-height:100vh;margin:0"><main style="max-width:560px;padding:32px;background:white;border-radius:18px;box-shadow:0 20px 60px rgba(15,35,70,.12);text-align:center"><h1>Restoring Aesthetic Intel</h1><p>The administrator is restoring a verified backup. Please wait a few minutes and refresh this page.</p></main></body></html>');
    }
}
$GLOBALS['app_config']=require ROOT_PATH.'/config/app.php';
date_default_timezone_set((string)($GLOBALS['app_config']['timezone']??'UTC'));
require APP_PATH.'/helpers.php';
require APP_PATH.'/reporting-period.php';
require APP_PATH.'/auth.php';
require APP_PATH.'/parsers.php';
require APP_PATH.'/analytics.php';
require APP_PATH.'/upload.php';
require APP_PATH.'/gbp.php';
require APP_PATH.'/openai.php';
require APP_PATH.'/boulevard-api.php';
require APP_PATH.'/ai-extraction.php';
require APP_PATH.'/report-validation.php';
require APP_PATH.'/unified-report.php';
require APP_PATH.'/data-transfer.php';
require APP_PATH.'/backup.php';
require APP_PATH.'/business-delete.php';
require APP_PATH.'/features.php';
require APP_PATH.'/provider-kpi.php';
require APP_PATH.'/documentation.php';
require APP_PATH.'/smart-search.php';
require APP_PATH.'/ai-report-review.php';
require APP_PATH.'/migrations.php';
if(session_status()!==PHP_SESSION_ACTIVE){
 session_name((string)app_config('session_name','aesthetic_intel_session'));
 session_set_cookie_params(['lifetime'=>0,'path'=>'/','secure'=>!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off','httponly'=>true,'samesite'=>'Lax']);
 session_start();
}
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('Referrer-Policy: strict-origin-when-cross-origin');
$dbFile=ROOT_PATH.'/config/database.php';
if(!is_file($dbFile)){if(basename($_SERVER['SCRIPT_NAME']??'')!=='install.php'){header('Location: '.base_url('install.php'));exit;}return;}
$dbConfig=require $dbFile;
$dsn=sprintf('mysql:host=%s;port=%s;dbname=%s;charset=%s',$dbConfig['host'],$dbConfig['port']??'3306',$dbConfig['name'],$dbConfig['charset']??'utf8mb4');
$pdo=new PDO($dsn,$dbConfig['user'],$dbConfig['password'],[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>false]);
$GLOBALS['pdo']=$pdo;
run_app_migrations();
if(auth_check())auth_sync_security_state();
if(auth_check()){
 $last=(int)($_SESSION['last_activity']??time());
 if(time()-$last>(int)app_config('session_timeout',7200)){auth_logout();session_start();flash('warning','Your session expired. Please sign in again.');header('Location: '.url('login'));exit;}
 $_SESSION['last_activity']=time();
}
