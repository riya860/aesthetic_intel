<?php
return array (
  'host' => 'localhost',
  'port' => '3306',
  'name' => 'u571425787_ai',
  'user' => 'u571425787_ai',
  'password' => '{7Sp7xB65h]/',
  'charset' => 'utf8mb4',
);
