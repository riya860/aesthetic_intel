<?php
$adminParams=[];
$businessId=(int)business_context_id();
$features=business_feature_effective_states($businessId);
$boulevardEnabled=!empty($features['boulevard']);
$boulevardApiEnabled=$boulevardEnabled&&!empty($features['boulevard_api']);
$gbpEnabled=!empty($features['gbp']);
$podiumEnabled=!empty($features['podium']);
$growth99Enabled=!empty($features['growth99']);
$ga4Enabled=!empty($features['ga4']);
$providerKpiShow=!empty($features['provider_kpi'])&&provider_kpi_navigation_visible($businessId);
$autoBoulevard=$boulevardApiEnabled&&!empty($boulevardUserAccess['enabled']);
$boulevardActionUrl=(!$autoBoulevard||auth_is_admin())?url('business-upload',$adminParams):url('business-boulevard-run');
$boulevardActionLabel=(!$autoBoulevard||auth_is_admin())?'Add Data':'Run Weekly Report';
$hasDashboardFeatures=$boulevardEnabled||$gbpEnabled||$podiumEnabled||$growth99Enabled||$ga4Enabled||$providerKpiShow;
?>
<div class="page-head"><div><span class="eyebrow"><?=e($business['name'])?></span><h1>Performance Dashboard</h1><p>Choose an enabled source, add the latest data, and turn it into one clear performance story.</p></div><a class="btn btn-primary" href="<?=url('business-history',$adminParams)?>">Open Reports</a></div>

<?php if($hasDashboardFeatures):?>
<section class="source-grid source-grid-premium">
 <?php if($boulevardEnabled):?><article class="source-card"><div class="source-main"><div class="source-icon source-boulevard">B</div><div><h3>Boulevard</h3><p><?=$autoBoulevard&&!auth_is_admin()?'Run the approved weekly API report with one click.':'Revenue, appointments, memberships, retail, and provider performance.'?></p></div></div><div class="source-actions"><a class="btn btn-primary" href="<?=e($boulevardActionUrl)?>"><?=e($boulevardActionLabel)?></a><a class="btn btn-secondary" href="<?=url('business-history',$adminParams)?>">History</a></div></article><?php endif;?>
 <?php if($gbpEnabled):?><article class="source-card"><div class="source-main"><div class="source-icon source-gbp">G</div><div><h3>Google Business Profile</h3><p>Track calls, directions, website clicks, interactions, and reviews.</p></div></div><div class="source-actions"><a class="btn btn-primary" href="<?=url('business-gbp',$adminParams)?>">Add Data</a><a class="btn btn-secondary" href="<?=url('business-gbp-history',$adminParams)?>">History</a></div></article><?php endif;?>
 <?php if($podiumEnabled):?><article class="source-card"><div class="source-main"><div class="source-icon source-podium">P</div><div><h3>Podium</h3><p>Upload Inbox and Calls reports for AI-powered extraction.</p></div></div><div class="source-actions"><a class="btn btn-primary" href="<?=url('business-ai-extraction',['source'=>'podium']+$adminParams)?>">Upload Report</a></div></article><?php endif;?>
 <?php if($growth99Enabled):?><article class="source-card"><div class="source-main"><div class="source-icon source-growth">99</div><div><h3>Growth99+</h3><p>Bring in lead, Cliffhanger, and CallRail insight reports.</p></div></div><div class="source-actions"><a class="btn btn-primary" href="<?=url('business-ai-extraction',['source'=>'growth99']+$adminParams)?>">Upload Report</a></div></article><?php endif;?>
 <?php if($ga4Enabled):?><article class="source-card"><div class="source-main"><div class="source-icon source-ga4">G4</div><div><h3>Google Analytics 4</h3><p>Extract users, engagement, page views, clicks, and conversions.</p></div></div><div class="source-actions"><a class="btn btn-primary" href="<?=url('business-ai-extraction',['source'=>'ga4']+$adminParams)?>">Upload Report</a></div></article><?php endif;?>
 <?php if($providerKpiShow):?><article class="source-card source-card-provider-kpi"><div class="source-main"><div class="source-icon source-provider-kpi">KPI</div><div><h3>Provider KPI Dashboard</h3><p>Provider scorecards, monthly goals, clinic rollups, and performance visibility.</p></div></div><div class="source-actions"><a class="btn btn-primary" href="<?=url('business-provider-kpi')?>">Open Dashboard</a></div></article><?php endif;?>
</section>
<?php else:?>
<section class="empty-state"><div class="empty-icon">⚙</div><h2>Workspace is ready</h2><p>No optional business features are enabled right now. <?php if(auth_is_admin()):?>Use Edit Business → Feature Controls to turn on only the tools this business needs.<?php else:?>Ask your Super Admin to enable the tools your team uses.<?php endif;?></p><?php if(auth_is_admin()):?><a class="btn btn-primary" href="<?=url('admin-business-form',['id'=>$businessId])?>">Manage Feature Controls</a><?php endif;?></section>
<?php endif;?>

<?php if($boulevardEnabled):?>
 <?php if($latest):$latestValidationStatus=(string)($latest['validation_status']??'validated');?>
  <?php if(!report_validation_is_allowed($latestValidationStatus)):?>
  <section class="panel feature-panel validation-dashboard-hold"><div><span class="validation-badge validation-danger">Review required</span><h2>Latest Boulevard report is being held safely</h2><p><?=e(reporting_us_date($latest['period_start']))?> – <?=e(reporting_us_date($latest['period_end']))?> is not being used as the current comparison because Report Intelligence found a possible period or data issue.</p></div><a class="btn btn-secondary" href="<?=url('business-report',['id'=>$latest['id']]+$adminParams)?>">Review Report</a></section>
  <?php else:$d=json_decode($latest['dashboard_json'],true)?:[];?>
  <div class="panel-head dashboard-section-head"><div><span class="eyebrow">Latest snapshot</span><h2>Boulevard Performance</h2></div><a href="<?=url('business-report',['id'=>$latest['id']]+$adminParams)?>">View report</a></div><div class="kpi-grid four"><?php foreach(array_slice($d['kpis']??[],0,4,true) as $m):?><article class="kpi-card"><small><?=e($m['label'])?></small><strong><?=metric_display($m)?></strong><span class="trend trend-<?=e($m['sentiment']??'neutral')?>"><?=e(change_text($m))?></span></article><?php endforeach;?></div><section class="panel feature-panel"><div><span class="status status-completed">Latest Boulevard report ready</span><h2><?=e(reporting_us_date($latest['period_start']))?> – <?=e(reporting_us_date($latest['period_end']))?></h2><p>Review the complete interactive infographic, provider performance, memberships, retail details, and insights.</p></div><a class="btn btn-primary" href="<?=url('business-report',['id'=>$latest['id']]+$adminParams)?>">Open Full Report</a></section>
  <?php endif;?>
 <?php else:?><section class="empty-state"><div class="empty-icon">B</div><h2>No Boulevard report yet</h2><p><?=$autoBoulevard&&!auth_is_admin()?'Run the approved weekly Boulevard report. Aesthetic Intel will continue processing in the background.':'Upload one or more Boulevard CSV exports to create the first performance dashboard.'?></p><a class="btn btn-primary" href="<?=e($boulevardActionUrl)?>"><?=$autoBoulevard&&!auth_is_admin()?'Run Weekly Report':'Start First Upload'?></a></section><?php endif;?>
<?php endif;?>

<?php if($gbpEnabled):?>
 <?php if($latestGbp):$latestGbpValidation=(string)($latestGbp['validation_status']??'validated');?>
  <?php if(!report_validation_is_allowed($latestGbpValidation)):?>
  <section class="panel feature-panel validation-dashboard-hold"><div><span class="validation-badge validation-danger">Review required</span><h2>Latest Google Business Profile data is being held safely</h2><p><?=e(reporting_us_date($latestGbp['period_start']))?> – <?=e(reporting_us_date($latestGbp['period_end']))?> is not being used for automatic activity comparisons until it is reviewed.</p></div><a class="btn btn-secondary" href="<?=url('business-gbp-report',['id'=>$latestGbp['id']]+$adminParams)?>">Review GBP Report</a></section>
  <?php else:$previous=gbp_previous_entries((int)$business['id'],(string)$latestGbp['period_end'],(int)$latestGbp['id'],2,(string)$latestGbp['frequency'],(string)$latestGbp['period_start']);$ga=gbp_build_analysis($latestGbp,$previous);?>
  <section class="panel"><div class="panel-head"><div><span class="eyebrow">Latest snapshot</span><h2>Google Business Profile</h2><p class="muted"><?=e(reporting_us_date($latestGbp['period_start']))?> – <?=e(reporting_us_date($latestGbp['period_end']))?></p></div><a class="btn btn-secondary" href="<?=url('business-gbp-report',['id'=>$latestGbp['id']]+$adminParams)?>">Open GBP Report</a></div><div class="kpi-grid four"><?php foreach(['interactions','calls','directions','website_clicks'] as $key):$x=$ga['metrics'][$key];?><article class="kpi-card"><small><?=e($x['label'])?></small><strong><?=$x['activity']===null?'Baseline':numfmt($x['activity'])?></strong><span class="trend trend-neutral"><?=e(gbp_activity_text($x))?></span></article><?php endforeach;?></div></section>
  <?php endif;?>
 <?php else:?><section class="panel feature-panel"><div><span class="status status-draft">GBP ready to configure</span><h2>Add your first GBP baseline</h2><p>Enter the current cumulative totals. The next entry will calculate new activity automatically.</p></div><a class="btn btn-primary" href="<?=url('business-gbp',$adminParams)?>">Add GBP Baseline</a></section><?php endif;?>
<?php endif;?>

<?php if($boulevardEnabled):?><section class="panel"><div class="panel-head"><div><span class="eyebrow">Timeline</span><h2>Recent Boulevard Reports</h2></div><a href="<?=url('business-history',$adminParams)?>">View all</a></div><div class="history-cards"><?php foreach($history as $h):?><a class="history-card" href="<?=$h['status']==='completed'?url('business-report',['id'=>$h['id']]+$adminParams):'#'?>"><strong><?=e(reporting_us_date($h['period_start']))?> – <?=e(reporting_us_date($h['period_end']))?></strong><?php if($h['status']==='completed'):$hm=report_validation_status_meta($h['validation_status']??'validated');?><span class="validation-badge validation-<?=e($hm['class'])?>"><?=e($hm['label'])?></span><?php else:?><span class="status status-<?=e($h['status'])?>"><?=e(ucfirst($h['status']))?></span><?php endif;?></a><?php endforeach;?><?php if(!$history):?><p class="muted">No Boulevard history yet.</p><?php endif;?></div></section><?php endif;?>
